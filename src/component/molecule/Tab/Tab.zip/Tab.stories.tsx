import {Meta, StoryObj} from '@storybook/react-native';
import Tab from './Tab';
import {Box, Button, ScrollView, Text} from '@/component/atom';
import useCountdown from '@/hooks/useCountDown';
import {withBackgrounds} from '@storybook/addon-ondevice-backgrounds';
import {useTheme} from '@shopify/restyle';
import {Theme} from '@/typings/globalTheme';
import LTab from './LTab';
import LinearTab from './LinearTab';
import {getFontSizeByWindowWidth} from '@/style/theme';

const TabMeta: Meta<typeof Tab> = {
  title: 'Tab',
  component: Tab,
  decorators: [
    withBackgrounds,
    Story => (
      <ScrollView
        py={'vm'}
        flex={1}
        contentContainerStyle={{
          paddingBottom: 100,
          justifyContent: 'center',
          flexGrow: 1,
        }}
        // px={'hm'}
      >
        <Text
          textAlign={'center'}
          variant={'header'}
          mb={'vxl'}
          textDecorationLine={'underline'}>
          Tabs
        </Text>
        <Story />
      </ScrollView>
    ),
  ],
};

type story = StoryObj<typeof TabMeta>;

// export const Default: story = {};
const tabData = [
  {
    title: 'Tab 1',
    renderScene: () => (
      <Box width={'100%'} bg={'green100'} pt={'vl'} height={100}>
        <Text>You don't like this right</Text>
      </Box>
    ),
  },
  {
    title: 'Tab 2',
    renderScene: () => (
      <Box height={100}>
        <Text>You don't like this left</Text>
      </Box>
    ),
  },
  {
    title: 'Tab 3',
    renderScene: () => (
      <Box height={100}>
        <Text>but you like it center </Text>
      </Box>
    ),
  },
  {
    title: 'Tab 4',
    renderScene: () => (
      <Box height={100}>
        <Text>but you like it center </Text>
      </Box>
    ),
  },
  {
    title: 'Tab 5',
    renderScene: () => (
      <Box height={100}>
        <Text>but you like it center </Text>
      </Box>
    ),
  },
];

export const Tabs: StoryObj<typeof TabMeta> = {
  render: args => {
    return (
      <Box gap={'vxl'}>
        <Box gap={'vxs'} alignItems={'center'}>
          <Text color={'white'} variant={'headings'}>
            Tabss
          </Text>
          <Box
            width={'100%'}
            style={
              {
                // paddingHorizontal: 20,
              }
            }>
            <Tab mH={getFontSizeByWindowWidth(20)} gap={10} tabData={tabData} />
            {/* <Tab paddingHorizontal={spacing.hl} /> */}
          </Box>
        </Box>
      </Box>
    );
  },
};

export const LTabs: StoryObj<typeof TabMeta> = {
  render: args => {
    // const DURATION = 5000;
    const DURATION = 16000;
    const {start, formattedTime, reset, time} = useCountdown({
      callback: () => {},
      duration: DURATION,
    });
    const {spacing} = useTheme<Theme>();

    return (
      <Box gap={'vxl'}>
        <Box gap={'vxs'} alignItems={'center'}>
          <Box width={'100%'}>
            <LTab />
          </Box>
        </Box>
      </Box>
    );
  },
};
export const AnimatedLTabs: StoryObj<typeof TabMeta> = {
  render: args => {
    // const DURATION = 5000;
    const DURATION = 16000;
    const {start, formattedTime, reset, time} = useCountdown({
      callback: () => {},
      duration: DURATION,
    });
    const {spacing} = useTheme<Theme>();

    return (
      <Box gap={'vxl'}>
        <Box gap={'vxs'} alignItems={'center'}>
          <Box width={'100%'}>
            <LinearTab />
          </Box>
        </Box>
      </Box>
    );
  },
};

export default TabMeta;
